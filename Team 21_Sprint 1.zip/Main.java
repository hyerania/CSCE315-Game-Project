/**
 * Created by Karl on 3/9/2017.
 */
import java.util.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.event.*;
import java.awt.*;
import static java.lang.System.*;

public class Main {
    public static final int ROWS = 2;
    public static final int COLUMNS = 6;
    public static int[][]board = new int[ROWS][COLUMNS];    //int [row][column]
    public static int computerEndHouse;
    public static int userEndHouse;
    public static boolean computersTurn = false;
    public static boolean goAgain = false;


    public static void main(String[] args) {

        final int STARTING_SEEDS = 4;
        //populating board
        for(int r = 0; r < ROWS; r++)
        {
            for(int c = 0; c < COLUMNS; c++)
            {
                board[r][c] = STARTING_SEEDS;
            }
        }

        Home h = new Home();        //Makes home screen of game
    }
}

class Home extends JFrame
{
    private static final int WIDTH = 1200;
    private static final int HEIGHT = 700;
    private JFrame mainFrame = new JFrame("Mancala Board");
    private JPanel controlPanel;

    JButton userPlayers = new JButton("Two-User Player");
    JButton computerPlayer = new JButton("Single-User Player");
    JButton helpMenu = new JButton("Help Menu");
    JButton exitGame = new JButton("Exit Game");

    JLabel status1 = new JLabel("");
    JLabel status2 = new JLabel("");

    JLabel userPlayer1Label = new JLabel("Player 1 Name: ", 4);
    JLabel userPlayer2Label = new JLabel("Player 2 Name: ", 4);
    JTextField userPlayer1 = new JTextField(10);
    JTextField userPlayer2 = new JTextField(10);

    public Home(){
        mainFrame.setSize(1200, 700);
        mainFrame.setLayout(new GridLayout(0, 2));
        mainFrame.setDefaultCloseOperation(3);
        mainFrame.setVisible(true);

        controlPanel = new JPanel();
        controlPanel.setLayout(new FlowLayout());

        mainFrame.add(userPlayers);
        mainFrame.add(computerPlayer);
        mainFrame.add(helpMenu);
        mainFrame.add(exitGame);
        mainFrame.add(controlPanel);

        controlPanel.add(userPlayer1Label);
        controlPanel.add(userPlayer1);
        controlPanel.add(userPlayer2Label);
        controlPanel.add(userPlayer2);
        userPlayers.addActionListener(new userPlayersAction());
        computerPlayer.addActionListener(new computerPlayersAction());
        helpMenu.addActionListener(new helpMenuAction());
        exitGame.addActionListener(new exitGameAction());
    }

    class userPlayersAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String player1 = userPlayer1.getText();
            String player2 = userPlayer2.getText();
            userPlayer1.setText("");
            userPlayer2.setText("");
            mainFrame.setVisible(false);
            Game g = new Game();
        }
    }

    class computerPlayersAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            String player1 = userPlayer1.getText();
            userPlayer1.setText("");
            mainFrame.setVisible(false);
            Game g = new Game();
        }
    }
    class helpMenuAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            HelpMenu help = new HelpMenu();
        }
    }
    class exitGameAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            System.exit(0);
        }
    }

}

class HelpMenu extends JFrame
{
    private JFrame mainHelpFrame = new JFrame("Game Help");

    public HelpMenu(){
        mainHelpFrame.setSize(500,500);
        mainHelpFrame.setVisible(true);
        JTextArea instructions = new JTextArea(content,20,20);
        instructions.setLineWrap(true);
        instructions.setWrapStyleWord(true);
        mainHelpFrame.add(new JScrollPane(instructions));
    }

    static String content = "Instructions for Game:\n";
}

class Game extends JFrame
{
    private static final int WIDTH = 1200;
    private static final int HEIGHT = 700;

    //buttons for the game
    JButton userHouse1;
    JButton userHouse2;
    JButton userHouse3;
    JButton userHouse4;
    JButton userHouse5;
    JButton userHouse6;

    JLabel userSeedNumber1;
    JLabel userSeedNumber2;
    JLabel userSeedNumber3;
    JLabel userSeedNumber4;
    JLabel userSeedNumber5;
    JLabel userSeedNumber6;


    JLabel computerHouse1;
    JLabel computerHouse2;
    JLabel computerHouse3;
    JLabel computerHouse4;
    JLabel computerHouse5;
    JLabel computerHouse6;

    JLabel computerSeedNumber1;
    JLabel computerSeedNumber2;
    JLabel computerSeedNumber3;
    JLabel computerSeedNumber4;
    JLabel computerSeedNumber5;
    JLabel computerSeedNumber6;

    JLabel userEndHouseLabel;
    JLabel userEndHouseNum;
    JLabel computerEndHouseLabel;
    JLabel computerEndHouseNum;

    JLabel empty1;
    JLabel empty2;
    JLabel empty3;
    JLabel empty4;


    public Game()
    {
        setTitle("Mancala Board");

        //instantiate buttons
        userHouse1 = new JButton("House 1");
        userHouse2 = new JButton("House 2");
        userHouse3 = new JButton("House 3");
        userHouse4 = new JButton("House 4");
        userHouse5 = new JButton("House 5");
        userHouse6 = new JButton("House 6");

        userSeedNumber1 = new JLabel("" + Main.board[1][0] );
        userSeedNumber1.setVerticalTextPosition(JLabel.CENTER);
        userSeedNumber1.setHorizontalTextPosition(JLabel.CENTER);
        userSeedNumber2 = new JLabel("" + Main.board[1][1] );
        userSeedNumber2.setVerticalTextPosition(JLabel.CENTER);
        userSeedNumber2.setHorizontalTextPosition(JLabel.CENTER);
        userSeedNumber3 = new JLabel("" + Main.board[1][2] );
        userSeedNumber3.setVerticalTextPosition(JLabel.CENTER);
        userSeedNumber3.setHorizontalTextPosition(JLabel.CENTER);
        userSeedNumber4 = new JLabel("" + Main.board[1][3] );
        userSeedNumber4.setVerticalTextPosition(JLabel.CENTER);
        userSeedNumber4.setHorizontalTextPosition(JLabel.CENTER);
        userSeedNumber5 = new JLabel("" + Main.board[1][4] );
        userSeedNumber5.setVerticalTextPosition(JLabel.CENTER);
        userSeedNumber5.setHorizontalTextPosition(JLabel.CENTER);
        userSeedNumber6 = new JLabel("" + Main.board[1][5] );
        userSeedNumber6.setVerticalTextPosition(JLabel.CENTER);
        userSeedNumber6.setHorizontalTextPosition(JLabel.CENTER);

        computerHouse1 = new JLabel("House 1");
        computerHouse1.setVerticalTextPosition(JLabel.CENTER);
        computerHouse1.setHorizontalTextPosition(JLabel.CENTER);
        computerHouse2 = new JLabel("House 2");
        computerHouse2.setVerticalTextPosition(JLabel.CENTER);
        computerHouse2.setHorizontalTextPosition(JLabel.CENTER);
        computerHouse3 = new JLabel("House 3");
        computerHouse3.setVerticalTextPosition(JLabel.CENTER);
        computerHouse3.setHorizontalTextPosition(JLabel.CENTER);
        computerHouse4 = new JLabel("House 4");
        computerHouse4.setVerticalTextPosition(JLabel.CENTER);
        computerHouse4.setHorizontalTextPosition(JLabel.CENTER);
        computerHouse5 = new JLabel("House 5");
        computerHouse5.setVerticalTextPosition(JLabel.CENTER);
        computerHouse5.setHorizontalTextPosition(JLabel.CENTER);
        computerHouse6 = new JLabel("House 6");
        computerHouse6.setVerticalTextPosition(JLabel.CENTER);
        computerHouse6.setHorizontalTextPosition(JLabel.CENTER);

        computerSeedNumber1 = new JLabel("" + Main.board[0][0] );
        computerSeedNumber1.setVerticalTextPosition(JLabel.CENTER);
        computerSeedNumber1.setHorizontalTextPosition(JLabel.CENTER);
        computerSeedNumber2 = new JLabel("" + Main.board[0][1]);
        computerSeedNumber2.setVerticalTextPosition(JLabel.CENTER);
        computerSeedNumber2.setHorizontalTextPosition(JLabel.CENTER);
        computerSeedNumber3 = new JLabel("" + Main.board[0][2]);
        computerSeedNumber3.setVerticalTextPosition(JLabel.CENTER);
        computerSeedNumber3.setHorizontalTextPosition(JLabel.CENTER);
        computerSeedNumber4 = new JLabel("" + Main.board[0][3]);
        computerSeedNumber4.setVerticalTextPosition(JLabel.CENTER);
        computerSeedNumber4.setHorizontalTextPosition(JLabel.CENTER);
        computerSeedNumber5 = new JLabel("" + Main.board[0][4]);
        computerSeedNumber5.setVerticalTextPosition(JLabel.CENTER);
        computerSeedNumber5.setHorizontalTextPosition(JLabel.CENTER);
        computerSeedNumber6 = new JLabel("" + Main.board[0][5]);
        computerSeedNumber6.setVerticalTextPosition(JLabel.CENTER);
        computerSeedNumber6.setHorizontalTextPosition(JLabel.CENTER);

        userEndHouseLabel = new JLabel("User End House" );
        userEndHouseLabel.setVerticalTextPosition(JLabel.CENTER);
        userEndHouseLabel.setHorizontalTextPosition(JLabel.CENTER);
        userEndHouseNum = new JLabel("" + Main.userEndHouse );
        userEndHouseNum.setVerticalTextPosition(JLabel.CENTER);
        userEndHouseNum.setHorizontalTextPosition(JLabel.CENTER);

        computerEndHouseLabel = new JLabel("Computer End House" );
        computerEndHouseLabel.setVerticalTextPosition(JLabel.CENTER);
        computerEndHouseLabel.setHorizontalTextPosition(JLabel.CENTER);
        computerEndHouseNum = new JLabel("" + Main.computerEndHouse );
        computerEndHouseNum.setVerticalTextPosition(JLabel.CENTER);
        computerEndHouseNum.setHorizontalTextPosition(JLabel.CENTER);

        empty1 = new JLabel(" " );
        empty1.setVerticalTextPosition(JLabel.CENTER);
        empty1.setHorizontalTextPosition(JLabel.CENTER);
        empty2 = new JLabel(" " );
        empty2.setVerticalTextPosition(JLabel.CENTER);
        empty2.setHorizontalTextPosition(JLabel.CENTER);
        empty3 = new JLabel(" " );
        empty3.setVerticalTextPosition(JLabel.CENTER);
        empty3.setHorizontalTextPosition(JLabel.CENTER);
        empty4 = new JLabel(" " );
        empty4.setVerticalTextPosition(JLabel.CENTER);
        empty4.setHorizontalTextPosition(JLabel.CENTER);


        add (empty1);
        add (computerHouse1);
        add (computerHouse2);
        add (computerHouse3);
        add (computerHouse4);
        add (computerHouse5);
        add (computerHouse6);
        add (empty2);

        add (computerEndHouseLabel);
        add (computerSeedNumber1);
        add (computerSeedNumber2);
        add (computerSeedNumber3);
        add (computerSeedNumber4);
        add (computerSeedNumber5);
        add (computerSeedNumber6);
        add (userEndHouseLabel);

        add (computerEndHouseNum);
        add (userSeedNumber1);
        add (userSeedNumber2);
        add (userSeedNumber3);
        add (userSeedNumber4);
        add (userSeedNumber5);
        add (userSeedNumber6);
        add ( userEndHouseNum);

        add (empty3);
        add (userHouse1);
        add (userHouse2);
        add (userHouse3);
        add (userHouse4);
        add (userHouse5);
        add (userHouse6);
        add (empty4);

        userHouse1.addActionListener(new UserHouse1Action ());
        userHouse2.addActionListener(new UserHouse2Action ());
        userHouse3.addActionListener(new UserHouse3Action ());
        userHouse4.addActionListener(new UserHouse4Action ());
        userHouse5.addActionListener(new UserHouse5Action ());
        userHouse6.addActionListener(new UserHouse6Action ());



        Container pane = getContentPane();
        pane.setLayout(new GridLayout(4, 8));


        setSize(WIDTH, HEIGHT);
        setVisible(true);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    boolean isGameOver()
    {
        int countComputer = 0;
        int countUser = 0;
        for(int x=0; x< Main.COLUMNS; x++)
        {
            countComputer += Main.board[0][x];
            countUser += Main.board[1][x];
        }
        return ((countComputer == 0) || (countUser == 0));
    }

    void movingSeeds(int seeds, int r, int c)
    {
        //int numSeeds = seeds;

        for(int x=0; x < seeds; x++)
        {
            if(c >= Main.COLUMNS || c < 0)
            {
                //this makes sure that seeds are not added to the end zone of the other player.
                if(r==1)
                {
                    r--;
                    c = Main.COLUMNS - 1;
                    if(!Main.computersTurn)     //if it is users turn then add to their end zone.
                    {
                        Main.userEndHouse++;
                        if(x+1 >= seeds)        //if that is the last seed then go again
                        {
                            Main.goAgain = true;
                        }
                    }
                    continue;
                }
                else
                {
                    r++;
                    c = 0;
                    if(Main.computersTurn)      //if it is computers turn then add to its end zone
                    {
                        Main.computerEndHouse++;    //will need to do the go again thing for the computer
                        if(x+1 >= seeds)
                        {
                            Main.goAgain = true;
                        }

                    }

                    continue;
                }
            }
            //if this is the last seed and the place where it is landing is empty
            //Then take all of the seeds in the matching house only if the empty house is on your side.
            if((x+1 >= seeds) && (Main.board[r][c] == 0))
            {
                if(r == 1 && !(Main.computersTurn))
                {
                    Main.userEndHouse += Main.board[r-1][c];
                    Main.board[r-1][c] = 0;
                }
                else
                if(r == 0 && Main.computersTurn)
                {
                    Main.computerEndHouse += Main.board[r+1][c];
                    Main.board[r+1][c] = 0;
                }

            }

            Main.board[r][c]++;


            if(r == 1)
            {
                c++;
            }
            else
            {
                c--;
            }
        }

        //if the game is over then it quits the program and prints out the results
        //in the future probably want to do this in GUI as well.
        if(isGameOver())
        {
            setVisible(false);
            findWinner();
            exit(0);
        }

    }

    void findWinner()
    {
        int totalUserSeeds = Main.userEndHouse;
        int totalComputerSeeds = Main.computerEndHouse;

        //adds all of the seeds remaining in the houses after the game has ended.
        for(int r = 0; r < Main.ROWS; r++)
        {
            for(int c = 0; c < Main.COLUMNS; c++)
            {
                if(r == 0)
                {
                    totalComputerSeeds += Main.board[r][c];
                }
                else
                {
                    totalUserSeeds += Main.board[r][c];
                }
            }
        }

        //Decide winner then print out
        if(totalUserSeeds > totalComputerSeeds)
        {
            out.println("Congratulations you beat the computer with a score of " + totalUserSeeds + " to " + totalComputerSeeds + ".");
        }
        else
        if(totalComputerSeeds > totalUserSeeds)
        {
            out.println("Sorry you lost to the computer with a score of " + totalComputerSeeds + " to " + totalUserSeeds + ".");
        }
        else
        {
            out.println("You have tied the computer.");
        }

    }

    class UserHouse1Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            //So that buttons can't be clicked when it is the computers turn and when that house is empty.
            if(!Main.computersTurn && !(Main.board[1][0] == 0))
            {
                int numSeeds = Main.board[1][0];
                Main.board[1][0] = 0;
                int r = 1;
                int c = 1;
                movingSeeds(numSeeds, r, c);

                if(!Main.goAgain)
                {
                    Main.computersTurn = true;
                    computerTurn();
                }
                Main.goAgain = false;

                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                //not a very good way to reload the frame. Look at example code more.
                setVisible(false);
                Game g = new Game();
                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            }



        }
    }
    class UserHouse2Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if(!Main.computersTurn && !(Main.board[1][1] == 0))
            {
                int numSeeds = Main.board[1][1];
                Main.board[1][1] = 0;
                int r = 1;
                int c = 2;
                movingSeeds(numSeeds, r, c);

                if(!Main.goAgain)
                {
                    Main.computersTurn = true;
                    computerTurn();
                }
                Main.goAgain = false;

                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                //not a very good way to reload the frame. Look at example code more.
                setVisible(false);
                Game g = new Game();
                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            }

        }
    }
    class UserHouse3Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if(!Main.computersTurn && !(Main.board[1][2] == 0))
            {
                int numSeeds = Main.board[1][2];
                Main.board[1][2] = 0;
                int r = 1;
                int c = 3;
                movingSeeds(numSeeds, r, c);

                if(!Main.goAgain)
                {
                    Main.computersTurn = true;
                    computerTurn();
                }
                Main.goAgain = false;

                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                //not a very good way to reload the frame. Look at example code more.
                setVisible(false);
                Game g = new Game();
                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            }

        }
    }
    class UserHouse4Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if(!Main.computersTurn && !(Main.board[1][3] == 0))
            {
                int numSeeds = Main.board[1][3];
                Main.board[1][3] = 0;
                int r = 1;
                int c = 4;
                movingSeeds(numSeeds, r, c);

                if(!Main.goAgain)
                {
                    Main.computersTurn = true;
                    computerTurn();
                }
                Main.goAgain = false;

                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                //not a very good way to reload the frame. Look at example code more.
                setVisible(false);
                Game g = new Game();
                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            }



        }
    }
    class UserHouse5Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if(!Main.computersTurn && !(Main.board[1][4] == 0))
            {
                int numSeeds = Main.board[1][4];
                Main.board[1][4] = 0;
                int r = 1;
                int c = 5;
                movingSeeds(numSeeds, r, c);

                if(!Main.goAgain)
                {
                    Main.computersTurn = true;
                    computerTurn();
                }
                Main.goAgain = false;

                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                //not a very good way to reload the frame. Look at example code more.
                setVisible(false);
                Game g = new Game();
                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            }

        }
    }
    class UserHouse6Action implements ActionListener
    {
        public void actionPerformed(ActionEvent event)
        {
            if(!Main.computersTurn && !(Main.board[1][5] == 0))
            {
                int numSeeds = Main.board[1][5];
                Main.board[1][5] = 0;
                int r = 1;
                int c = 6;
                movingSeeds(numSeeds, r, c);

                if(!Main.goAgain)
                {
                    Main.computersTurn = true;
                    computerTurn();
                }
                Main.goAgain = false;

                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                //not a very good way to reload the frame. Look at example code more.
                setVisible(false);
                Game g = new Game();
                //~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
            }

        }
    }

     int psuedoMovingSeeds(int seeds, int r, int c)
    {
        int extra = 0;
        int[][] psuedoBoard = new int[Main.ROWS][Main.COLUMNS];
        for(int i = 0; i < Main.ROWS; i++)
        {

            for (int j = 0; j < Main.COLUMNS; j++)
            {
                psuedoBoard[i][j] = Main.board[i][j];
            }
        }
        int col= Main.COLUMNS;
        int row=Main.ROWS;
        int userEndHouse= Main.userEndHouse;
        boolean comp= Main.computersTurn;
        boolean go=Main.goAgain;
        int compEndHouse=Main.computerEndHouse;
        for(int x=0; x < seeds; x++)
        {
            if(c >= col || c < 0)
            {
                //this makes sure that seeds are not added to the end zone of the other player.
                if(r==1)
                {
                    r--;
                    c = col - 1;
                    if(!comp)     //if it is users turn then add to their end zone.
                    {
                        userEndHouse++;
                        if(x+1 >= seeds)        //if that is the last seed then go again
                        {
                            go = true;
                        }
                    }
                    continue;
                }
                else
                {
                    r++;
                    c = 0;
                    if(comp)      //if it is computers turn then add to its end zone
                    {
                        compEndHouse++;    //will need to do the go again thing for the computer
                        if(x+1 >= seeds)
                        {
                            go = true;
                        }

                    }

                    continue;
                }
            }
            //if this is the last seed and the place where it is landing is empty
            //Then take all of the seeds in the matching house only if the empty house is on your side.
            if((x+1 >= seeds) && (psuedoBoard[r][c] == 0))
            {
                if(r == 1 && !(comp))
                {
                    userEndHouse += psuedoBoard[r-1][c];
                    psuedoBoard[r-1][c] = 0;
                }
                else
                if(r == 0 && comp)
                {
                    compEndHouse += psuedoBoard[r+1][c];
                    psuedoBoard[r+1][c] = 0;
                }

            }

            psuedoBoard[r][c]++;

            if(r == 1)
            {
                c++;
            }
            else
            {
                c--;
            }
        }
        //if negative then User is winning if postive then computer winning
        if(go == true)
        {
            extra = 100;
        }
        out.println(compEndHouse-userEndHouse + extra);
        return compEndHouse-userEndHouse + extra;
        
    }

    
    public GameObject minimax(GameObject go, int depth, boolean maxTree)
    {   //returns the column that should be executed
        if(depth == 0 || go.column == 6){
            //return value;
            return go;
        }
        //check if Game Over
        if(maxTree){
            // if it is the computer does the minimax tree with all the potential moves
            ArrayList<GameObject>moves= new ArrayList<GameObject>();

            int bestValue = Integer.MIN_VALUE;  
            int bestCol=0;

            for(int i=0; i<Main.COLUMNS; i++)
            {
                if(Main.board[0][i] != 0)
                {
                    int value = psuedoMovingSeeds(Main.board[0][i],0,i-1);
                    GameObject node = new GameObject(i, value);
                    GameObject abc= minimax(node,depth-1, false);
                    bestValue= Math.max(bestValue, abc.value);
                    if(bestValue==abc.value)
                    {
                        bestCol=abc.column;
                    }
                }

                // GameObject node= new GameObject();
                //return moves.get(moves.size()-1);
            }
            GameObject returnObj = new GameObject(bestCol,bestValue);        
            return returnObj;
        }
        else 
        {
           // int moves[]= new int[6];
            int bestValue = Integer.MAX_VALUE;
            int bestCol=0;
            for(int i=0; i<Main.COLUMNS; i++)
            {
                if(Main.board[0][i] != 0)
                {
                    int value = psuedoMovingSeeds(Main.board[0][i],0,i-1);
                    GameObject node = new GameObject(i, value);
                    GameObject abc= minimax(node,depth-1, true);
                    bestValue= Math.min(bestValue, abc.value);
                    if(bestValue==abc.value)
                    {
                        bestCol=abc.column;
                    }
                }

                // GameObject node= new GameObject();
                //return moves.get(moves.size()-1);
            }
            GameObject returnObj = new GameObject(bestCol,bestValue);        
            return returnObj;
        }
    }
    void computerTurn()
    {
        //one problem is that this will do all the turns that the computer can do then it will show up on the GUI.
        do
        {
            Main.goAgain = false;

            GameObject go= new GameObject(0,Main.computerEndHouse, Main.userEndHouse);
            GameObject current = minimax(go, 3, true);
           // out.println(num);
            movingSeeds(Main.board[0][current.column], 0, current.column-1);
            Main.board[0][current.column]=0;
            //Temporary testing~~~~~~~~
            //movingSeeds(Main.board[0][3], 0, 2);
            //Main.board[0][3] = 0;
            //~~~~~~~~~~~~~
        }while(Main.goAgain);       //movingSeeds will set goAgain to the correct value.

        Main.computersTurn = false;     //So that the buttons will be clickable again
    }

}

class GameObject
{
    int column = 6;
    //int[][]board = new int[ROWS][COLUMNS];    //int [row][column]
    int computerEndZone;
    int userEndZone;
    int value;
    //public static boolean computersTurn = false;
    //public static boolean goAgain = false;

    GameObject(int c,int cez, int uez)
    {
        column=c;
        computerEndZone=cez;
        userEndZone=uez;
    }
    GameObject(int c, int v)
    {
        column = c;
        value = v;
    }
}