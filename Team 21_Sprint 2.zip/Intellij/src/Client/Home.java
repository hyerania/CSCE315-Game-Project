package Client;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.PrintWriter;

import static java.lang.System.out;

/**
 * Created by Hernandez-TAMU on 3/25/2017.
 */
class Home extends JFrame
{
    private static final int WIDTH = 1200;
    private static final int HEIGHT = 700;
    private JFrame mainFrame = new JFrame("Mancala Board");
    private JPanel controlPanel;

//    JButton userPlayers = new JButton("Two-User Player");
//    JButton computerPlayer = new JButton("Single-User Player");
    JButton start = new JButton("Start Game");
    JButton helpMenu = new JButton("Help Menu");
    JButton exitGame = new JButton("Exit Game");

//    JLabel status1 = new JLabel("");
//    JLabel status2 = new JLabel("");

//    JLabel userPlayer1Label = new JLabel("Player 1 Name: ", 4);
//    JLabel userPlayer2Label = new JLabel("Player 2 Name: ", 4);
//    JTextField userPlayer1 = new JTextField(10);
//    JTextField userPlayer2 = new JTextField(10);

    JLabel userPlayerLabel = new JLabel("Player Name: ");
    JTextField userPlayer = new JTextField(10);

    static BufferedReader input;
    static PrintWriter output;      //maybe take out static
    String config;
    public int numHoles;
    public int numSeeds;
    public long timeLimit;
    public char isFirstPlayer;
    public char gameMode;

    public Home(BufferedReader in, PrintWriter out, String configuration){
        input = in;
        output = out;
        config = configuration;

        String configPass[] = config.split(" ");
        numHoles = Integer.parseInt(configPass[1]);
        numSeeds = Integer.parseInt(configPass[2]);
        timeLimit = Long.parseLong(configPass[3]);
        isFirstPlayer = configPass[4].charAt(0);
        gameMode = configPass[5].charAt(0);


        mainFrame.setSize(1200, 700);
        mainFrame.setLayout(new FlowLayout());
        mainFrame.setDefaultCloseOperation(3);
        mainFrame.setVisible(true);

        mainFrame.add(userPlayerLabel);
        mainFrame.add(userPlayer);

        mainFrame.add(start);
        mainFrame.add(helpMenu);
        mainFrame.add(exitGame);
//        mainFrame.add(controlPanel);

//        userPlayers.addActionListener(new userPlayersAction());
//        computerPlayer.addActionListener(new computerPlayersAction());
        start.addActionListener(new startGame());
        helpMenu.addActionListener(new helpMenuAction());
        exitGame.addActionListener(new exitGameAction());
    }

//    class userPlayersAction implements ActionListener {
//        public void actionPerformed(ActionEvent e) {
//            String player1 = userPlayer1.getText();
//            String player2 = userPlayer2.getText();
//            userPlayer1.setText("");
//            userPlayer2.setText("");
//            mainFrame.setVisible(false);
//            /*
//            Get the number of seeds, if it is a random distribution, and how many houses there should be.(columns)
//
//            set Main.COLUMNS to how many houses they want. (Must be at least 4 and at most 9)
//
//            Main.board = new int[Main.ROWS][Main.COLUMNS];
//            also put this ^ before the populate.
//
//            then populate the board
//            Main.populateBoard(int numOfSeeds, boolean isRandom);
//             */
//
//            //for testing purposes~~~~~~~~~~~
//            Main.COLUMNS = 5;
//            Main.board = new int [Main.ROWS][Main.COLUMNS];
//            Main.populateBoard(4, false);
//            out.println(Main.COLUMNS);
//            Game g = new Game();
//        }
//    }
//
//    class computerPlayersAction implements ActionListener{
//        public void actionPerformed(ActionEvent e){
//            String player1 = userPlayer1.getText();
//            userPlayer1.setText("");
//            mainFrame.setVisible(false);
//
//            /*
//            Get the number of seeds, if it is a random distribution, and how many houses there should be.(columns)
//
//            set Main.COLUMNS to how many houses they want. (Must be at least 4 and at most 9)
//
//            Main.board = new int[Main.ROWS][Main.COLUMNS];
//            also put this ^ before the populate.
//
//            then populate the board
//            Main.populateBoard(int numOfSeeds, boolean isRandom);
//             */
//
//            //for testing purposes~~~~~~~~~~~
//            Main.COLUMNS = 5;
//            Main.board = new int [Main.ROWS][Main.COLUMNS];
//            Main.populateBoard(4, false);       //change to true if you want to be random numbers in the houses
//            //~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//            Game g = new Game();
//        }
//    }

    class startGame implements  ActionListener{
        public void actionPerformed(ActionEvent e){
            Main.COLUMNS = numHoles;
            Main.board = new int[Main.ROWS][Main.COLUMNS];
            if(gameMode == 'S'){
                Main.populateBoard(numSeeds, false);
            }
            else if(gameMode == 'R'){
                Main.populateBoard(numSeeds, true);
            }
            output.println("READY");
            Game g = new Game();
            mainFrame.setVisible(false);
        }
    }
    class helpMenuAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            HelpMenu help = new HelpMenu();
        }
    }
    class exitGameAction implements ActionListener{
        public void actionPerformed(ActionEvent e){
            System.exit(0);
        }
    }

}

class HelpMenu extends JFrame
{
    private JFrame mainHelpFrame = new JFrame("Game Help");

    public HelpMenu(){
        mainHelpFrame.setSize(500,500);
        mainHelpFrame.setVisible(true);
        JTextArea instructions = new JTextArea(content,20,20);
        instructions.setLineWrap(true);
        instructions.setWrapStyleWord(true);
        mainHelpFrame.add(new JScrollPane(instructions));
    }

    static String content = "Instructions for Game:\n";
}
