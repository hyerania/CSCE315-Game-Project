package Client;

import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

/**
 * Created by Hernandez-TAMU on 3/24/2017.
 */
public class MainClient {
    public static void main(String[] args) throws IOException {
        System.out.println("Client started!");
        String serverAddress = JOptionPane.showInputDialog("Enter IP Address of a server:");
        Socket s = new Socket(serverAddress, 9090);

        BufferedReader input = new BufferedReader(new InputStreamReader(s.getInputStream()));
        String welcome = input.readLine();
        String configuration = input.readLine();

        System.out.println(welcome);
        System.out.println(configuration);

        PrintWriter output = new PrintWriter(s.getOutputStream(), true);
        new Home(input, output, configuration);
        String begin = input.readLine();

        if(begin.equals("BEGIN")){
            System.out.println("Game begins!");

            //@TODO Communicate moves from game board
        }
    }

}
