Team Number: 21
Team Members:Karl Lawson, Sneha Santani, Yerania Hernandez

Instructions:
We have included our entire project for this Sprint, which as been done through IntelliJ as a Java Application. All the files that have been used will be found in the folder "src".
All our files have been tested on the IDE: Intellij. In IntelliJ, it has compiled and ran fully functional.
It is currently divided between "Client" and "Server" folder, and will need to be run with the "Client" and "Server" configurations. There are currently 2 types of clients, "Client" and "ClientAI", which one is used for a player and other one is used for the computer in order to run any algorithm necessary.
Start the "Server" first and then run as two different "Clients" in order to start the game.