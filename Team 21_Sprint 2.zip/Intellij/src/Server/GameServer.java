package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Random;
import java.util.StringJoiner;
import java.util.Timer;
import java.util.TimerTask;
import static java.lang.System.*;

import static java.lang.System.exit;

/**
 * Created by Hernandez-TAMU on 3/25/2017.
 */
public class GameServer implements Runnable{
    int columns, numSeeds;
    final int ROWS = 2;

    boolean player1Turn = true; //added
    boolean goAgain = false;
    int board[][];
    int player1EndZone;
    int player2EndZone;

    long timeLimit;
    char gameMode;
    Socket socketP1;
    Socket socketP2;

    PrintWriter outputP1;
    PrintWriter outputP2;

    BufferedReader inputP1;
    BufferedReader inputP2;

    public GameServer(int holes, int seeds, long time, char mode){
        columns = holes;
        numSeeds = seeds;
        timeLimit = time;
        gameMode = mode;
        board = new int[2][columns];

        if(gameMode == 'S'){
            populateBoard(numSeeds, false);
        }
        else if(gameMode == 'R'){
            populateBoard(numSeeds, true);
        }

        //create board

    }
    //should populate board
    void populateBoard(int numSeeds, boolean random)
    {
        if(!random)
        {
            for(int r = 0; r < 2; r++)
            {
                for(int c = 0; c < columns; c++)
                {
                    board[r][c] = numSeeds;
                }
            }
        }
        else
        {
            Random ran = new Random();
            int sumOfAllSeeds = numSeeds * columns;

            for(int r = 0; r < 2; r++)
            {
                for(int c = 0; c < columns; c++)
                {
                    if(r == 0)
                    {
                        int seedVal =  ran.nextInt(sumOfAllSeeds);
                        board[r][c] = seedVal;
                        sumOfAllSeeds -= seedVal;
                    }
                    else
                    {
                        board[r][c] = board[r-1][columns-c-1];
                    }

                }
            }
        }


    }

    public String sendConfig(Boolean isFirstPlayer){
        StringJoiner joinConfig = new StringJoiner(" ");
        joinConfig.add("INFO");
        joinConfig.add(Integer.toString(columns));
        joinConfig.add(Integer.toString(numSeeds));
        joinConfig.add(Long.toString(timeLimit));
        if(isFirstPlayer){
            joinConfig.add("F");
        }
        else{
            joinConfig.add("S");
        }
        joinConfig.add(Character.toString(gameMode));

        return joinConfig.toString();
    }

    public void addPlayer(Socket socket, Boolean isFirstPlayer) {
        try{
            if(isFirstPlayer){
                socketP1 = socket;
                outputP1 = new PrintWriter(socket.getOutputStream(), true);
                outputP1.println("WELCOME");
                outputP1.println(sendConfig(isFirstPlayer));
            }
            else{
                socketP2 = socket;
                outputP2 = new PrintWriter(socket.getOutputStream(), true);
                outputP2.println("WELCOME");
                outputP2.println(sendConfig(isFirstPlayer));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

//@TODO Timer works, must implement sending messages from server to client
//    public class Reminder{
//        Timer timer;
//        public Reminder(long timeLimit){
//            timer = new Timer();
//            timer.schedule(new RemindTask(), timeLimit);
//        }
//        class RemindTask extends TimerTask{
//            public void run(){
//                System.out.println("TIME");
//                timer.cancel();
//            }
//        }
//    }

@Override
        public void run(){
            String readyP1 = null;
            String readyP2 = null;

            try {
                inputP1 = new BufferedReader(new InputStreamReader(socketP1.getInputStream()));
                inputP2 = new BufferedReader(new InputStreamReader(socketP2.getInputStream()));
                readyP1 = inputP1.readLine();
                readyP2 = inputP2.readLine();

                if(readyP1.equals("READY") && readyP2.equals("READY")){
                    outputP1.println("BEGIN");
                    outputP2.println("BEGIN");

                    //@TODO Time limit functions, need to send/receive client/server
//                    if(timeLimit != 0){
//                        new Reminder(timeLimit);
//                    }

                    //recieving and sending messages
                    while(true)
                    {
                        if(player1Turn)
                        {
                            //gets move from user(just the column of the house)
                            int move = Integer.parseInt(inputP1.readLine());
                            //PASS THE COLUMN OF MOVE STARTING AT ZERO
                            if(board[1][move] == 0)
                            {
                                //TODO implement game over logic here. Automatically player 2 wins
                                break;
                            }
                            //update board
                            int numSeeds = board[1][move];
                            board[1][move] = 0;
                            movingSeeds(numSeeds, 1, move+1);

                            //UPDATES THE SERVER BOARD CORRECTLY!!!

                            //pass the move to player2
                            outputP2.println("" + (columns-move -1));

                            //switches turns
                            if(!goAgain)
                            {
                                player1Turn = false;
                            }
                            goAgain = false;

                        }
                        else       //player 2's turn
                        {
                            int move = Integer.parseInt(inputP2.readLine());
                            //PASS THE COLUMN OF MOVE STARTING AT ZERO
                            if(board[0][move] == 0)
                            {
                                //TODO implement game over logic here. Automatically player 1 wins
                                break;
                            }
                            //update board
                            int numSeeds = board[0][columns - 1 -move];
                            board[0][columns - 1- move] = 0;
                            movingSeeds(numSeeds, 0, columns - 2 - move);

                            for(int r = 0; r <2; r++)
                            {
                                for (int c =0; c< columns; c++)
                                {
                                    out.print(board[r][c] + " ");
                                }
                                out.println();
                            }

                            //pass the move to player1
                            outputP1.println("" + (columns-move -1));

                            //switches turns
                            if(!goAgain)
                            {
                                player1Turn = true;
                            }
                            goAgain = false;

                        }

                    }


                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            //@TODO All move information needs to be here, for player and computers
        }
    void movingSeeds(int seeds, int r, int c)
    {
        //int numSeeds = seeds;

        for(int x=0; x < seeds; x++)
        {
            if(c >= columns || c < 0)
            {
                //this makes sure that seeds are not added to the end zone of the other player.
                if(r==1)
                {
                    r--;
                    c = columns - 1;
                    if(player1Turn)     //if it is users turn then add to their end zone.
                    {
                        player1EndZone++;
                        if(x+1 >= seeds)        //if that is the last seed then go again
                        {
                            goAgain = true;    //not sure if i need this
                        }
                    }
                    continue;
                }
                else
                {
                    r++;
                    c = 0;
                    if(!player1Turn)      //if it is computers turn then add to its end zone
                    {
                        player2EndZone++;    //will need to do the go again thing for the computer
                        if(x+1 >= seeds)
                        {
                            goAgain = true;
                        }

                    }

                    continue;
                }
            }
            //if this is the last seed and the place where it is landing is empty
            //Then take all of the seeds in the matching house only if the empty house is on your side.
            if((x+1 >= seeds) && (board[r][c] == 0))
            {
                if(r == 1 && player1Turn)
                {
                    player1EndZone += board[r-1][c];
                    board[r-1][c] = 0;
                }
                else
                if(r == 0 && !player1Turn)
                {
                    player2EndZone += board[r+1][c];
                    board[r+1][c] = 0;
                }

            }

            board[r][c]++;


            if(r == 1)
            {
                c++;
            }
            else
            {
                c--;
            }
        }

        //if the game is over then it quits the program and prints out the results
        //in the future probably want to do this in GUI as well.
        if(isGameOver())
        {
            findWinner();
            exit(0);    //probably change this TODO change to notify
        }

    }
    boolean isGameOver()
    {
        int countComputer = 0;
        int countUser = 0;
        for(int x=0; x< columns; x++)
        {
            countComputer += board[0][x];
            countUser += board[1][x];
        }
        return ((countComputer == 0) || (countUser == 0));
    }
    void findWinner()
    {
        int player1Total = player1EndZone;
        int player2Total = player2EndZone;

        //adds all of the seeds remaining in the houses after the game has ended.
        for(int r = 0; r < ROWS; r++)
        {
            for(int c = 0; c < columns; c++)
            {
                if(r == 0)
                {
                    player2Total += board[r][c];
                }
                else
                {
                    player1Total += board[r][c];
                }
            }
        }

        if(player1Total > player2Total)     //player one wins
        {
            out.println("Player one wins with a score of " + player1Total + " to " + player2Total + ".");
        }
        else
        if(player2Total > player1Total)     //player two wins
        {
            out.println("Player two wins with a score of " + player2Total + " to " + player1Total + ".");
        }
        else        //they tied
        {
            out.println("Player one and player two have tied.");
        }

    }
}
