package Server;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import java.util.Properties;
import java.util.StringJoiner;

/**
 * Created by Hernandez-TAMU on 3/24/2017.
 */


public class MainServer {
    public static void main(String[] args) throws IOException {
        System.out.println("Game Server is running!");
        Properties prop = new Properties();
        InputStream input = null;
        ServerSocket listener = new ServerSocket(9090);
        String clientType = args[0];
        System.out.println(clientType);

        while (true) {
            try {
                //Should later accept arg[0] and fix configuration for further server implementations
                input = new FileInputStream("src/Server/configBoard.properties");
                prop.load(input); //load configuration
                int numHoles = Integer.parseInt(prop.getProperty("numHoles"));
                int numSeeds = Integer.parseInt(prop.getProperty("numSeeds"));
                long timeLimit = Long.parseLong(prop.getProperty("timeLimit"));
                char gameMode = prop.getProperty("gameMode").charAt(0);
                GameServer newGame = new GameServer(numHoles, numSeeds, timeLimit, gameMode);

                Socket socket = listener.accept();
                Boolean isFirstPlayer = true;
                newGame.addPlayer(socket, isFirstPlayer);
                if(clientType.equals("P1P2")){
                    socket = listener.accept();
                    isFirstPlayer = false;
                    newGame.addPlayer(socket, isFirstPlayer);
                    newGame.run();
                }
                else if(clientType.equals("P1C2")){
                    Socket socketAI = new Socket("localhost", 9090);
                    isFirstPlayer = false;
                    newGame.addPlayer(socketAI, isFirstPlayer);
                    newGame.run();
                }
                //@TODO Implementation of computer logic will need to be added
//                else if(clientType.equals("C1C2")){
//
//                }

            } catch (IOException ex) {
                ex.printStackTrace();
            } finally {
                if (input != null) {
                    try {
                        input.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}
