Team Number: 21
Team Members:Karl Lawson, Sneha Santani, Yerania Hernandez

Instructions:
We have included our entire project for this Sprint, which as been done through IntelliJ as a Java Application. All the files that have been used will be found in the folder "src".
All our files have been tested on the IDE: Intellij. In IntelliJ, it has compiled and ran fully functional.
It is currently divided between "Client" and "Server" folder, and will need to be run with the "Client" and "Server" configurations, with the "Server" accepting a parameter of "P1P2".
Start the "Server" first and then run as many "Clients" as needed.