Team Number: 21
Team Members:Karl Lawson, Sneha Santani, Yerania Hernandez

Instructions:
Our file Main.java was tested on the IDE: IntelliJ.
Main.java is the source file of our project in IntelliJ as a Java Application.
In IntelliJ, it was compiled and ran fully functional.